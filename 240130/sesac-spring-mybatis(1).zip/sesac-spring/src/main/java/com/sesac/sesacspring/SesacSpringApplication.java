package com.sesac.sesacspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SesacSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SesacSpringApplication.class, args);
	}

}
