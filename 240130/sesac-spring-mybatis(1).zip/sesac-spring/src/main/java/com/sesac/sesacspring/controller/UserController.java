package com.sesac.sesacspring.controller;

// Mybatis 수업 controller
public class UserController {
    // C, R
    // 1. Table 생성 완료 ( user )
    // 2. domain 만들기 ( domain/user )
    // 3. mapper 만들기 
    // 4. service 만들기
    // 5. controller 만들기
}
