package com.sesac.sesacspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SesacSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
